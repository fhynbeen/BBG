<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/css.css">
    <script type="text/javascript" src="semantic.js"></script>

    <meta charset="UTF-8">
    <title>BBG Games</title>
</head>
<body>
<img src="img/logo.png" width="150" style="position: absolute;">
<div id="titulo" style="text-align: center; ">
    <h1>Seja bem vindo ao BBG Games</h1>
    <h2>Uma metralhadora de notícias.</h2>
</div>
<div class="ui pointing menu" id="menu" style="padding-left: 10%">
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="index.php">
        Home
    </a>
    <a class="active item" style="padding-left: 30px; padding-right: 30px;" href="jogos.php">
        Jogos
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="noticias.php">
        Notícias
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="novidades.php">
        Novidades
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="contato.php">
        Fale Conosco
    </a>
    <div class="right menu" style="padding-right: 10%; border: 5px;">
        <form method="get" action="pesquisa.php">
            <div class="ui icon input">
                <input type="text" id="pesquisar" name="pesquisar" placeholder="Search...">
                <i class="circular search link icon"></i>
            </div>
        </form>
    </div>
    <a class="item" href="telaLogin.php">
        <i class="sign in alternate icon"></i>
    </a>
</div>
<div class="ui raised very padded text container segment" id="resenha">
    <h2 class="ui header">Sniper Elite 4</h2>
    <p><b>Criador:</b> Rebelliion Developments.</p>
    <p><b>Plataformas:</b> PS4, PC e Xbox One.</p>
    <p><b>Modo de jogo:</b> Modo missão principal onde o jogador elimina os adversários , objetivos secundários espalhados pelos mapas.</p>
    <p><b>Gameplay:</b> FPS de tiro</p>
    <p><b>Mapas:</b> Sobre os mapas, eles agora são maiores, permitindo criar ainda mais estratégias. De forma cooperativa ou partindo para o confronto direto, os cenários abertos facilitam na hora de fugir e se esconder, ou até mesmo escalar para buscar uma posição melhor para o disparo perfeito.</p>
    <div class="image" >
        <img src="img/se4.jpg" style="width: 500px">
    </div>
    Comentários:
    <div id="comentario">
        <div class="column">
            <div class="ui raised segment">
                <a class="ui grey ribbon label">Pedrinho chavozinho</a>
                <p>salkfhsalk jjdfks af lksa fnksafn mlksan</p>
                <div class="ui divider"></div>
                <a class="ui grey ribbon label">Alissinho gamer 777</a>
                <p>jogo top, curti skr skr top top</p>
            </div>
        </div>
    </div>
</div>

</body></html>
