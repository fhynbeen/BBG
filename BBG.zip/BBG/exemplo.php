<!--QUESTAO 1 a e b-->
<?php

    $json = file_get_contents("jogadores.json");
    $array_jogadores = json_decode($json, true);




?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Album da Copa</title>

    <!--QUESTAO 2-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>

	<div class="bg-light mb-5" id="cabecalho" >
		
		<div class="container">		
			<nav class="navbar navbar-expand-lg navbar-light">
				<img src="img/logo.png" width="30" height="30" alt="">

				<div id="navbarNav">
					<ul class="navbar-nav">
						
						<li class="nav-item">
							<a class="nav-link" href="index.php">Início</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#">Jogador</a>
						</li>

					</ul>
				</div>
			</nav>
		</div>
		
		<section class="jumbotron text-center rounded-0" style='background: url("img/bg.jpg")'>
			<div class="container">
				<h1 class="jumbotron-heading">Nosso álbum da copa</h1>
				<p class="lead text-muted">Neymito é o nosso Deus e nada me faltará</p>

			</div>
		</section>

	</div>

	<div id="conteudo" class="container">
		<div id="jogos" class="row">

            <!--QUESTAO 3-->
            <?php foreach ($array_jogadores as $key => $value) ?>


            <div id="jogador" class="col-sm-3 mb-5">

                <div  class="card">
                </div>

                    <div  class="card">


                        <img class="card-img-top" src= "img/figurinhas/<?= $value['imagem'] ?>" >
                        <div class="card-body">
                            <!--  Nome atleta -->
                            <h5 class="card-title">Jogador: <?= $value['nome'] ?> </h5>
                        </div>

                        <!-- Caracteristicas do Jogador -->
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">país: : <?= $value['pais'] ?>  </li>


                        </ul>
                        <div class="card-body">

                        <?= endforeach; ?>
                        </ul>
                        <div class="card-body">
                            <!--QUESTAO 5-->
                            <a href="..." class="card-link">saiba +</a>
                        </div>
                    </div>

			</div>

		</div>
	</div>

	
</body>
</html>