<?php
$json = file_get_contents('data_bases/resenhaCadastrada.json');
$array_jogos = json_decode($json, true);

$nome = $_GET['pesquisar'];
$jogo_encontrado = null;

foreach ($array_jogos as $jogo){
    if ( strtolower( $jogo['nomejogo']) == strtolower($nome) ||$jogo['abrevJogo'] == strtolower($nome) ){
        $jogo_encontrado = $jogo;
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/css.css">
    <script type="text/javascript" src="semantic.js"></script>

    <meta charset="UTF-8">
    <title>BBG Games</title>
</head>
<body>
<img src="img/logo.png" width="150" style="position: absolute;">
<div id="titulo" style="text-align: center; ">
    <h1>Seja bem vindo ao BBG Games</h1>
    <h2>Uma metralhadora de notícias.</h2>
</div>
<div class="ui pointing menu" id="menu" style="padding-left: 10%">
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="index2.php">
        Home
    </a>
    <a class="active item" style="padding-left: 30px; padding-right: 30px;" href="jogos2.php">
        Jogos
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="noticias2.php">
        Notícias
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="novidades2.php">
        Novidades
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="contato2.php">
        Fale Conosco
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="faq.php">
        FAQ
    </a>
    <div class="right menu" style="padding-right: 10%; border: 5px;">
        <form method="get" action="pesquisa2.php">
            <div class="ui icon input">
                <input type="text" id="pesquisar" name="pesquisar" placeholder="Search...">
                <i class="circular search link icon"></i>
            </div>
        </form>
    </div>
    <a class="item" href="perfil.php">
        <i class="user outline icon"></i>
    </a>
    <a class="item" href="cadastraResenha.php">
        <i class="file alternate outline icon"></i>
    </a>
    <a class="item" href="index.php">
        <i class="sign out alternate icon"></i>
    </a>
</div>

<div class="ui raised very padded text container segment" id="resenha">
    <h2 class="ui header"><?= $jogo_encontrado['nomejogo']?></h2>
    <p><b>Desenvolvedor: </b><?= $jogo_encontrado['desenvolvedor'] ?></p>
    <p><b>Plataforma: </b><?= $jogo_encontrado['plataformas'] ?></p>
    <p><b>Gameplay: </b><?= $jogo_encontrado['gameplay'] ?></p>
    <p><b>Mapas: </b><?= $jogo_encontrado['mapas'] ?></p>
    <div class="image" >
        <img src="img/<?= $jogo_encontrado['img'] ?>" style="width: 500px">
    </div>
    Comentários:
    <div id="comentario">
        <div class="column">
            <div class="ui raised segment">
                <a class="ui grey ribbon label">Pedrinho chavozinho</a>
                <p>salkfhsalk jjdfks af lksa fnksafn mlksan</p>
                <div class="ui divider"></div>
                <a class="ui grey ribbon label">Alissinho gamer 777</a>
                <p>jogo top, curti skr skr top top</p>
                <div class="ui divider"></div>
                <a href="perfil.php" class="ui blue ribbon label">user2345678</a>
                <p>bla bla blabla bla blabla bla blabla bla blabla bla bla</p>
            </div>
            <button class="ui red small square button">
                Excluir
            </button>
            <button class="ui green button small square">
                Editar
            </button>
        </div>
    </div><br>
    <div id="adcComentario">
        <textarea rows="3" style="padding-right: 70%; border-radius: 8px" placeholder="Adicionar comentário."></textarea>

    </div>
    <div>
        <button class="ui button grey">Comentar</button>
    </div>
</div>


</body></html>
